package com.example.retail.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.retail.ProductModel;
import com.example.retail.R;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {
    private List<ProductModel> productList;
    private Context context;
    private OnProductClickListener onProductClickListener;
    private OnAddProductClickListener onAddProductClickListener;

    public interface OnProductClickListener{
        void onProductClick(View view , int position);
    }
    public interface   OnAddProductClickListener{
        void onAddProductClick(View view ,int position);
    }

    public ProductAdapter(List<ProductModel> productList, Context context, OnProductClickListener onProductClickListener, OnAddProductClickListener onAddProductClickListener) {
        this.productList = productList;
        this.context = context;
        this.onProductClickListener = onProductClickListener;
        this.onAddProductClickListener = onAddProductClickListener;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.product_rv_item,parent,false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {

        ProductModel productModel=productList.get(position);
        holder.productTitleTv.setText(productModel.getTitle());
        holder.productDetailsTV.setText(productModel.getDetails());
        holder.productPriceTV.setText(productModel.getPrice());
        Glide.with(context).load(productModel.getImage()).into(holder.productIv);


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
           onProductClickListener.onProductClick(v,holder.getAdapterPosition());
            }
        });

        holder.addProductsIb.setOnClickListener(new  View.OnClickListener(){

            @Override
            public void onClick(View v) {
                onAddProductClickListener.onAddProductClick(v,holder.getAdapterPosition());
            }
        });



    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

   class ProductViewHolder extends RecyclerView.ViewHolder {
        ImageView productIv;
        TextView productTitleTv;
        TextView productDetailsTV;
        TextView productPriceTV;
        ImageButton addProductsIb;

       public ProductViewHolder(@NonNull View itemView) {
           super(itemView);
           productIv=itemView.findViewById(R.id.product_iv);
           productTitleTv=itemView.findViewById(R.id.product_title_tv);
           productDetailsTV=itemView.findViewById(R.id.product_details_tv);
           productPriceTV=itemView.findViewById(R.id.product_price_tv);
           addProductsIb=itemView.findViewById(R.id.add_product_ib);

       }
   }
}
