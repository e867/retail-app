package com.example.retail.fragments;

public interface GridSpacingItemDecoration {
}
